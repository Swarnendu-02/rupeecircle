<!DOCTYPE html>
<html lang="en" ng-app="app" ng-controller="AppCtrl">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Rupee Circle</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/odometer.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/chart.min.js"></script>

</head>

<body>
    <div class="prf-header d-flex align-items-center justify-content-between">
        <p class="header-title mb-0"><img src="	http://34.131.215.77:8080/app/common/img/logo.png"></p>
        <a class="student-profile ">
            <img src="https://www.neet-o-meter.com/vclasses/assets/images/account.png">
        </a>
        <div class="prf-box-slide">
            <a title="Home" href='https://www.neet-o-meter.com/vclasses/'><i class="fas fa-cog"></i><span>Settings</span></a>
            <a href="#"><i class="fas fa-user"></i><span>Profile</span></a>
            <a title="Logout" href='https://www.neet-o-meter.com/vclasses/logout.php'><i class="fas fa-sign-out-alt"></i><span>Log Out</span></a>
        </div>
        <script>
            $(".student-profile").click(function() {
                $(".prf-box-slide").toggle();
            });
        </script>
    </div>
    <div class="content-area">
        <div class="tab-content active" data-id="7">
            <div class="dpp-grid">
                <div class="p-5 bg-white shadow rounded">
                    <div class="invest-info">
                        <h3>I want to</h3>
                        <h4><span>Invest:</span> <input></h4>
                        <div class="dis-grid g-4 my-5">
                            <label class="contain">
                                <input type="radio" checked="checked" name="radio">
                                <span class="checkmark">One</span>
                            </label>
                            <label class="contain">
                                <input type="radio" name="radio">
                                <span class="checkmark">One</span>
                            </label>
                            <label class="contain">
                                <input type="radio" name="radio">
                                <span class="checkmark">One</span>
                            </label>
                            <label class="contain">
                                <input type="radio" name="radio">
                                <span class="checkmark">One</span>
                            </label>
                        </div>
                        <h4><span>Return:</span> <input></h4>
                    </div>
                    <div class="mt-4">
                        <label class="w-100 mt-2"><input class="mr-3" type="checkbox">T&C</label>
                        <label class="w-100 mt-2"><input class="mr-3" type="checkbox">T&C</label>
                    </div>

                </div>

                <div class="btn-con text-right">
                    <a href="#" class="light btn-success">Continue<i class="fas fa-arrow-right ml-3"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.tablinks').click(function() {
                $(".tab-content").removeClass('active');
                $(".tab-content[data-id='" + $(this).attr('data-id') + "']").addClass("active");
                $(".tablinks").removeClass('active-a');
                $(this).addClass('active-a');

            });

        });
    </script>
</body>
<div class="md-wrap" style="display: none;">
    <div class="md-body d-flex align-items-center justify-content-center h-100 w-100">
        <div class="md-box rounded position-relative">
            <a style="position: absolute;right: 20px;top: 20px;"><i class="fas fa-times"></i></a>
            <div class="col-12 form-group ">
                <h3>Select payment method</h3>
            </div>
            <div>
                <label class="w-100 mt-2"><input class="mr-3" type="checkbox">A</label>
                <label class="w-100 mt-2"><input class="mr-3" type="checkbox">B</label>
            </div>
            <div class="btn-con text-center mt-5">
                <a href="#" class="light btn-success">Continue<i class="fas fa-arrow-right ml-3"></i></a>
            </div>
        </div>
    </div>
</div>
<div class="md-wrap">
    <div class="md-body d-flex align-items-center justify-content-center h-100 w-100">
    <div class="md-box rounded position-relative">
          
          <h2 style="
  text-align: center;
  font-weight: bold;
  font-size: 44px;
  margin-bottom: 60px;
  color: #008f45;
  text-transform: uppercase;
">Congratulation!</h2>
          <div class="col-12 form-group ">
              <h2 style="
  text-align: center;
  margin-bottom: 28px;
  font-size: 76px;
  color: #ff6739;
"><i class="fas fa-check-circle"></i></h2>
              <h3 class="text-center" style="
  /* color: #ff6739; */
">Investment Successfull</h3>
          </div>
          <div class="btn-con text-center mt-5">
              <a href="#" class="light btn-success">Continue<i class="fas fa-arrow-right ml-3"></i></a>
          </div>
      </div>
    </div>
</div>
</html>