<!DOCTYPE html>
<html lang="en" ng-app="app" ng-controller="AppCtrl">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Rupee Circle</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/odometer.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/chart.min.js"></script>

</head>

<body>
    <div class="prf-header d-flex align-items-center justify-content-between">
        <p class="header-title mb-0"><img src="	http://34.131.215.77:8080/app/common/img/logo.png"></p>
        <a class="student-profile ">
            <img src="https://www.neet-o-meter.com/vclasses/assets/images/account.png">
        </a>
        <div class="prf-box-slide">
            <a title="Home" href='https://www.neet-o-meter.com/vclasses/'><i class="fas fa-cog"></i><span>Settings</span></a>
            <a href="#"><i class="fas fa-user"></i><span>Profile</span></a>
            <a title="Logout" href='https://www.neet-o-meter.com/vclasses/logout.php'><i class="fas fa-sign-out-alt"></i><span>Log Out</span></a>
        </div>
        <script>
            $(".student-profile").click(function() {
                $(".prf-box-slide").toggle();
            });
        </script>
    </div>
    <div class="content-area">
        <div class="sub-header d-flex align-items-center justify-content-between mb-4">
            <div class="d-flex align-items-center">

            </div>
            <div class="d-flex align-items-center justify-content-end">
                <a href="javascript:void(0);" class="tablinks active-a" data-id="7">Details</a>
                <a href="javascript:void(0);" class="tablinks" data-id="8">About</a>
            </div>
        </div>
        <div class="tab-content active" data-id="7">
            <div class="dpp-grid">
                <div class="p-5 bg-white shadow rounded d-flex align-items-center justify-content-between">
                    <div class="invest-info">
                        <h3>Upto 13% returns</h3>
                        <h4><span>Min Investment:</span> 15000/-</h4>
                        <h4><span>Tensure:</span> 6 Months</h4>
                    </div>
                    

                </div>
                <div class="p-5 bg-white shadow rounded">
                    <h4 class="inner-heading mb-4">What is P2P?</h4>
                    <div class="content">
                        <p>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</p>
                    </div>
                </div>
                <div class="p-5 bg-white shadow rounded">
                    <h4 class="inner-heading mb-4">Why we like?</h4>
                    <div class="content">
                        <p>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</p>
                    </div>
                </div>
                <div class="btn-con text-right">
                        <a href="#" class="light btn-success">Continue<i class="fas fa-arrow-right ml-3"></i></a>
                    </div>
            </div>
        </div>
        <div class="tab-content" data-id="8">
            <div class="p-5 bg-white shadow rounded">
                <div class="content">
                    <p>In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content. Lorem ipsum may be used as a placeholder before final copy is available.</p>
                </div>
        </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('.tablinks').click(function() {
                $(".tab-content").removeClass('active');
                $(".tab-content[data-id='" + $(this).attr('data-id') + "']").addClass("active");
                $(".tablinks").removeClass('active-a');
                $(this).addClass('active-a');

            });

        });
    </script>
</body>

</html>