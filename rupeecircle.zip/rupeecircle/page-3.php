<!DOCTYPE html>
<html lang="en" ng-app="app" ng-controller="AppCtrl">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Rupee Circle</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/odometer.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/chart.min.js"></script>

</head>

<body>
    <div class="prf-header d-flex align-items-center justify-content-between">
        <p class="header-title mb-0"><img src="	http://34.131.215.77:8080/app/common/img/logo.png"></p>
        <a class="student-profile ">
            <img src="https://www.neet-o-meter.com/vclasses/assets/images/account.png">
        </a>
        <div class="prf-box-slide">
            <a title="Home" href='https://www.neet-o-meter.com/vclasses/'><i class="fas fa-cog"></i><span>Settings</span></a>
            <a href="#"><i class="fas fa-user"></i><span>Profile</span></a>
            <a title="Logout" href='https://www.neet-o-meter.com/vclasses/logout.php'><i class="fas fa-sign-out-alt"></i><span>Log Out</span></a>
        </div>
        <script>
            $(".student-profile").click(function() {
                $(".prf-box-slide").toggle();
            });
        </script>
    </div>
    <div class="content-area">
        <div class="card-box">
            <h4 class="inner-heading mb-4">Portfolio</h4>
            <table class="table bg-white mb-0">
                <thead>
                    <tr role="row">
                        <th style="width:10%;">#</th>
                        <th>Investment Amount</th>
                        <th >Date</th>
                        <th >Tenure</th>
                        <th>Ex monthly amount</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>01/01/2023</td>
                        <td>test</td>
                        <td>Credit</td>
                        <td>Received</td>
                    </tr>

                </tbody>
            </table>
            <div class="btn-con text-right mt-5">
                <a href="#" class="light btn-primary ">Home</a>
                <a href="#" class="light btn-success">Click to investment</a>
            </div>
        </div>
    </div>
</body>

</html>