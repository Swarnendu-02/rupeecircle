<!DOCTYPE html>
<html lang="en" ng-app="app" ng-controller="AppCtrl">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Rupee Circle</title>
    <meta name="author" content="Alvaro Trigo Lopez" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="fullPage very simple demo." />
    <meta name="keywords" content="fullpage,jquery,demo,simple" />
    <meta name="Resource-type" content="Document" />
    <link rel="stylesheet" type="text/css" href="bootstrap-5/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responcive.css">
    <link href="css/owl.carousel.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/owl.theme.default.min.css?v=2" rel="stylesheet" type="text/css">
    <link href="css/odometer.css?v=2" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.css" />
    <script src="js/jquery.min.js"></script>
    <script src="js/chart.min.js"></script>

</head>

<body>
    <div class="login-bk d-md-flex align-items-center justify-content-center">
        <div class="col-12 getfrm login">
            <p class="mb-0 text-center"> <img src="http://34.131.215.77:8080/app/common/img/logo.png" style="margin-bottom: 3rem; width: 255px;"></p>
            <form id="contactForm" class="row m-0 p-5" onsubmit="return submitLoginForm();">
                <div class="col-12 form-group ">
                    <h3 class="text-white text-center mb-5">Login</h3>
                </div>
                <div class="col-12 form-group">
                    <div class="col-12 input-from-group rounded">
                        <input type="email" class="form-control" id="cemail" name="cemail" placeholder="Email">
                    </div>
                </div>
                <div class="col-12 form-group ">
                    <div class="col-12 input-from-group rounded">

                        <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Password">
                    </div>
                </div>
                <div class="col-12 mb-0 form-group text-center  ">
                    <button type="submit" class="main-btn-red " id="submit"><span class="position-relative">Login</span></button>
                    <p class="mb-0 mt-5 text-white"><a href="javascript:void(0);">Forgot Password</a></p>
                </div>
            </form>
            <form id="contactForm" class="row m-0 p-5 d-none" onsubmit="return submitLoginForm();">
                <div class="col-12 form-group ">
                    <h3 class="text-white text-center mb-5">Forgot Password</h3>
                </div>
                <div class="col-12 form-group">
                    <div class="col-12 input-from-group rounded">
                        <input type="email" class="form-control" id="cemail" name="cemail" placeholder="Email">
                    </div>
                </div>
                
                <div class="col-12 mb-0 form-group text-center  ">
                    <button type="submit" class="main-btn-red " id="submit"><span class="position-relative">Send</span></button>
                    <p class="mb-0 mt-5 text-white"><a href="javascript:void(0);">Click to Login</a></p>
                </div>
            </form>
        </div>
    </div>
</body>

</html>