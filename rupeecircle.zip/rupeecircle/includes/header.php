<header class="container-fluid">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col-9 col-md-3" style="display: flex;align-items: center;">
                <img src="images/logo.png" class="logo">
            </div>
            <div class="menu-box col-3 col-md-9 d-flex align-items-center justify-content-end" id="collapsemenu">
                <button onclick="$('.navigation').addClass('open');" style="background:#F51720 ;" class="d-md-none rounded main-btn-bk border-0 py-2 px-4 text-white"><i class="fas fa-bars"></i></button>
                <nav class="navigation" id="navigationmenu">
                    <button class="d-md-none" onclick="$('.navigation').removeClass('open'); $('.sub-menu').slideUp().removeClass('active');
                    $('.has-drop').removeClass('active-a');" style="    position: absolute;right: 19px;border: 0;background: transparent;color: white;top: 14px;font-size: 16px;"><i class="fas fa-arrow-right"></i></button>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about-us.php">About </a></li>
                        <li><a onclick="var position=$('#feature').position().top-100; gotoTop(position);">Features</a></li>
                        <li><a onclick="var position=$('#plans').position().top-100; gotoTop(position);">Plans</a></li>
                        <li><a onclick="var position=$('#testi').position().top-100; gotoTop(position);">Testimonials</a></li>
                        <li><a onclick="var position=$('#faq').position().top-100; gotoTop(position);">FAQ's</a></li>
                        <li><a href="contact-us.php">Contact</a></li>
                        <li><a href="#" class="main-btn-red">Login</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
</header>
<script>
     $(document).ready(function () {
        if ($(window).scrollTop() >= 100) {
            $('header').addClass('fixed-header');

        }
        else {
            $('header').removeClass('fixed-header');
        }
    });

    $(window).scroll(function () {
        if ($(window).scrollTop() >= 100) {
            $('header').addClass('fixed-header');
        }
        else {
            $('header').removeClass('fixed-header');
        }
    });
</script>